'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Search, User, ShoppingCart, Sun, Moon, Brain, Menu, ChevronDown } from 'lucide-react'
import { useUser } from '@/contexts/UserContext'
import { useCart } from '@/contexts/CartContext'
import { useTheme } from '@/components/ThemeProvider'
import {
 DropdownMenu,
 DropdownMenuContent,
 DropdownMenuItem,
 DropdownMenuLabel,
 DropdownMenuSeparator,
 DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useState } from 'react'
import { SearchBar } from '@/components/SearchBar'

export default function Header() {
 const { user, setUser } = useUser()
 const { items } = useCart()
 const { theme, setTheme } = useTheme()
 const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

 const handleLogout = () => {
   setUser(null)
 }

 const cartItemsCount = items.reduce((sum, item) => sum + item.quantity, 0)

 return (
   <header className="bg-primary text-primary-foreground p-4 relative overflow-hidden">
     <div className="absolute inset-0 bg-gradient-to-r from-primary to-accent opacity-50"></div>
     <div className="container mx-auto flex justify-between items-center relative z-10">
       <Link href="/" className="text-2xl font-bold flex items-center">
         <Brain className="mr-2" />
         Flamepath Academy
       </Link>
       <div className="flex items-center">
         <Button
           variant="ghost"
           className="md:hidden"
           onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
         >
           <Menu className="h-6 w-6" />
         </Button>
         <nav className="hidden md:flex items-center space-x-4">
           <Link href="/learning-hub" className="hover:text-primary-foreground/80 transition-colors">
             Learning Hub
           </Link>
           <DropdownMenu>
             <DropdownMenuTrigger asChild>
               <Button variant="ghost" className="p-0 font-normal hover:text-primary-foreground/80 transition-colors">
                 Resources <ChevronDown className="ml-1 h-4 w-4" />
               </Button>
             </DropdownMenuTrigger>
             <DropdownMenuContent>
               <DropdownMenuItem>
                 <Link href="/free-resources">Free Resources</Link>
               </DropdownMenuItem>
               <DropdownMenuItem>
                 <Link href="/paid-resources">Paid Resources</Link>
               </DropdownMenuItem>
               <DropdownMenuItem>
                 <Link href="/downloads">My Downloads</Link>
               </DropdownMenuItem>
             </DropdownMenuContent>
           </DropdownMenu>
         </nav>
         {mobileMenuOpen && (
           <div className="md:hidden absolute top-full left-0 right-0 bg-primary p-4 space-y-2">
             <Link href="/learning-hub" className="block hover:text-primary-foreground/80 transition-colors">
               Learning Hub
             </Link>
             <Link href="/free-resources" className="block hover:text-primary-foreground/80 transition-colors">
               Free Resources
             </Link>
             <Link href="/paid-resources" className="block hover:text-primary-foreground/80 transition-colors">
               Paid Resources
             </Link>
             <Link href="/downloads" className="block hover:text-primary-foreground/80 transition-colors">
               My Downloads
             </Link>
           </div>
         )}
       </div>
       <div className="flex items-center space-x-4">
         <div className="hidden md:block">
           <SearchBar />
         </div>
         <Button
           variant="ghost"
           size="icon"
           onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
         >
           {theme === 'light' ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
         </Button>
         {user ? (
           <>
             <Link href="/cart">
               <Button variant="ghost" className="relative p-2">
                 <ShoppingCart className="h-5 w-5" />
                 {cartItemsCount > 0 && (
                   <span className="absolute -top-1 -right-1 bg-secondary text-secondary-foreground rounded-full w-5 h-5 text-xs flex items-center justify-center animate-pulse">
                     {cartItemsCount}
                   </span>
                 )}
               </Button>
             </Link>
             <DropdownMenu>
               <DropdownMenuTrigger asChild>
                 <Button variant="ghost" className="p-2">
                   <User className="h-5 w-5" />
                 </Button>
               </DropdownMenuTrigger>
               <DropdownMenuContent>
                 <DropdownMenuLabel>My Account</DropdownMenuLabel>
                 <DropdownMenuSeparator />
                 <DropdownMenuItem className="md:hidden">
                   <Search className="mr-2 h-4 w-4" />
                   <span>Search</span>
                 </DropdownMenuItem>
                 <DropdownMenuItem>
                   <Link href="/dashboard">Dashboard</Link>
                 </DropdownMenuItem>
                 <DropdownMenuItem>
                   <Link href="/profile">Profile</Link>
                 </DropdownMenuItem>
                 <DropdownMenuItem>
                   <Link href="/cart">Cart ({cartItemsCount})</Link>
                 </DropdownMenuItem>
                 {user?.role === 'admin' && (
                   <>
                     <DropdownMenuItem>
                       <Link href="/admin">Admin Dashboard</Link>
                     </DropdownMenuItem>
                     <DropdownMenuItem>
                       <Link href="/admin/content-management">Content Management</Link>
                     </DropdownMenuItem>
                   </>
                 )}
                 <DropdownMenuItem onClick={handleLogout}>Logout</DropdownMenuItem>
               </DropdownMenuContent>
             </DropdownMenu>
           </>
         ) : (
           <>
             <Button variant="secondary">
               <Link href="/login">Login</Link>
             </Button>
             <Button variant="default">
               <Link href="/signup">Sign Up</Link>
             </Button>
           </>
         )}
       </div>
     </div>
   </header>
 )
}

