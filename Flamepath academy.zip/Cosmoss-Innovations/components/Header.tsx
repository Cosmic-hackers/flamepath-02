import Link from 'next/link';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem } from '@radix-ui/react-dropdown-menu';

function CoursesDropdown() {
  return (
    <DropdownMenu>
      <DropdownMenuContent>
        <DropdownMenuItem>
          <Link href="/courses/cyber-security">Cyber Security Fundamentals</Link>
        </DropdownMenuItem>
        <DropdownMenuItem>
          <Link href="/courses/penetration-testing">Penetration Testing for Beginners</Link>
        </DropdownMenuItem>
        <DropdownMenuItem>
          <Link href="/courses/ethical-hacking">Ethical Hacking: Zero to Hero</Link>
        </DropdownMenuItem>
        <DropdownMenuItem>
          <Link href="/courses/dos-ddos-telugu">DOS and DDOS Course (Telugu)</Link>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export default CoursesDropdown;

