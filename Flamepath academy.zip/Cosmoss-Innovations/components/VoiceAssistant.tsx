'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Mic, MicOff } from 'lucide-react'

export default function VoiceAssistant() {
  const [isListening, setIsListening] = useState(false)
  const [hasSpokenWelcome, setHasSpokenWelcome] = useState(false)

  useEffect(() => {
    if (!hasSpokenWelcome) {
      speakWelcomeMessage()
      setHasSpokenWelcome(true)
    }
  }, [hasSpokenWelcome])

  const toggleListening = () => {
    if (!isListening) {
      startListening()
    } else {
      stopListening()
    }
  }

  const startListening = () => {
    setIsListening(true)
    // Here you would implement actual speech recognition
    // For this example, we'll just simulate it
    console.log('Started listening...')
  }

  const stopListening = () => {
    setIsListening(false)
    // Here you would stop the speech recognition
    console.log('Stopped listening.')
  }

  const speakWelcomeMessage = () => {
    const welcomeMessage = "Welcome to Flamepath Academy. Explore our courses and resources to enhance your knowledge in technology and innovation."
    speak(welcomeMessage)
  }

  const speak = (text: string) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text)
      window.speechSynthesis.speak(utterance)
    } else {
      console.log("Text-to-speech not supported in this browser.")
    }
  }

  return (
    <Button onClick={toggleListening} variant="outline" className="fixed bottom-4 left-4">
      {isListening ? <MicOff /> : <Mic />}
      {isListening ? 'Stop Listening' : 'Start Voice Assistant'}
    </Button>
  )
}

