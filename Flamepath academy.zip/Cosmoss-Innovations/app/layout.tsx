<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
  </head>
  <body className={`${inter.className} bg-background text-foreground min-h-screen flex flex-col`}>
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
      <UserProvider>
        <CartProvider>
          <Header />
          <main className="flex-grow">{children}</main>
          <Footer />
          <AIChatbot />
          <VoiceAssistant />
        </CartProvider>
      </UserProvider>
    </ThemeProvider>
  </body>
</html>

