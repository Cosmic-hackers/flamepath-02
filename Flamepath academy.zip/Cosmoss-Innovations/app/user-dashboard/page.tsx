'use client'

import { useUser } from '@/contexts/UserContext'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

export default function UserDashboard() {
 const { user } = useUser()

 if (!user) {
   return <div>Please log in to view your dashboard.</div>
 }

 return (
   <div className="container mx-auto px-4 py-8">
     <h1 className="text-3xl font-bold mb-8">Welcome to Your Dashboard, {user.name}</h1>
     
     <Card className="mb-8">
       <CardHeader>
         <CardTitle>Your Profile</CardTitle>
       </CardHeader>
       <CardContent>
         <p><strong>Name:</strong> {user.name}</p>
         <p><strong>Email:</strong> {user.email}</p>
         <p><strong>Phone:</strong> {user.phone}</p>
         <p><strong>College:</strong> {user.college}</p>
         <p><strong>Profession:</strong> {user.profession}</p>
       </CardContent>
     </Card>
   </div>
 )
}

