\`\`\`tsx
import Link from 'next/link';
import { Button } from './components/Button';

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between p-24">
      <section className="text-center py-20 bg-gradient-to-r from-primary to-secondary text-primary-foreground">
        <h1 className="text-4xl font-bold mb-4">Welcome to Flamepath Academy</h1>
        <p className="text-xl mb-8">Your Guide to Mastering the Future of Technology</p>
        <Button asChild size="lg" variant="secondary">
          <Link href="/signup">Get Started Now</Link>
        </Button>
      </section>

      {/* rest of code here */}
    </main>
  )
}
\`\`\`

